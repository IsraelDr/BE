﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;
using System.Reflection;
using System.IO;

namespace DS
{
    public class DataSource
    {
        static public List<Nanny> NannyList = new List<BE.Nanny>();
        static public List<Mother> MotherList = new List<BE.Mother>();
        static public List<Child> ChildList = new List<BE.Child>();
        static public List<Contract> ContractList = new List<BE.Contract>();

    }
}
