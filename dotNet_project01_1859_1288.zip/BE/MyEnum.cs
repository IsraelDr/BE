﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class MyEnum
    {
        public enum Vacation { Chinuch, tamat }//Vacation_days = "Chinuch" or "tamat" { get; set; //Vacation days- "Chinuch" or "tamat"
        public enum Paymentmethode { houerly,  monthly }
       
    }
}


